import { TestBed } from '@angular/core/testing';

import { VideoGeneratorService } from './video-generator.service';

describe('VideoGeneratorService', () => {
  let service: VideoGeneratorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VideoGeneratorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
