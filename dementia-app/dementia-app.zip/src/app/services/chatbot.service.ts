import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ChatbotService {

  constructor() { }

  getResponse(query: string): string {
    return "This is a response to your query: " + query;
  }
}
